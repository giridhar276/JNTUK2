try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            # remove white spaces if any
            line = line.strip()
            print(line)
            
    ## logic2
    output = 1 + "hello"
except FileNotFoundError as err:
    print(err)
except TypeError as err:
    print(err)
except KeyError as err:
    print(err)
except (ValueError,FileExistsError,IndexError) as err:
    print("Error occured")
    print(err)        
except Exception as error:
    print("User defined:","File doesn't exist")
    print("System error :",error)