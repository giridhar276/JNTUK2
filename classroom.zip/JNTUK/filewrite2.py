#rite a program to write all the numbers 1 to 100 to the file line by line

fobj = open("numbers.txt","w")

for val in range(1,101):
    #print(val)
    fobj.write(str(val) + "\n")

fobj.close()



