book  = {"chap1":10 ,"chap2":20 ,"chap3":30 }


print(book)
# individual values
print(book["chap1"])   #10
print(book["chap2"])   #20
print(book["chap3"])   #30


book  = {"chap1":["Rita","UK",24] ,"chap2":["Rao","US",50] ,"chap3":["Gita","AUS",30] }
print(book)
print(book["chap1"])

print(book["chap100"])

# adding new  key:value pair
book["chap4"] = 400
print(book)