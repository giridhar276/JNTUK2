

name ="python"
print(len(name))

alist = [40,50,404]
print(len(alist))

adict = {"chap1":10 ,"chap2":20}
print(len(adict))




atup = (10,20,30,40)
#converting to list
alist= list(atup)
# make some change
alist[0] = 10000
# reconvert back to tuple
atuple = tuple(alist)
print("Elements are :", atuple)




name = input("Enter any string :")
print("You entered :", name)
# range(start,stop,step)
print(list(range(1,10)))
print(list(range(1,10,2)))
print(list(range(2,10,2)))

alist = [10,30,45,3,3]
print(max(alist))
print(min(alist))
print(sum(alist))

print(id(name))

#method1
print(type(name))
# method2 - isinstance()
name ="python"
print(isinstance(name,str))  # True
print(isinstance(name,list)) # False
alist = [20,30,4]
print(isinstance(alist,str))





















