


val1 = 10
val2 = 20

if val1 < val2:
    raise(Exception("Invalid logic"))