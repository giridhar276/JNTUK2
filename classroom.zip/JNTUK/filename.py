


#Write a Python program to capture any filename from the keyboard 
#and display its filename and extension separately.


filename = input("Enter any filename :")   # info.docx

print("You entered :", filename)

output = filename.split(".")    # [info ,   docx]

print("Filename :", output[0])
print("Extension:", output[1])