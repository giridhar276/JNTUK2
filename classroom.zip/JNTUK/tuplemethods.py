

atup = (10,30,40)

atup.