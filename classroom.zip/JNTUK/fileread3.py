

with open("realestate.csv") as fobj :
    for line in fobj:
        line = line.strip()
        output = line.split(",")
        print(output[0])
        print(output[1])
        print("--------------")