

color = input("Enter any color:")

if color == "red":
    print("You entered RED")
elif color == "green":
    print("YOu entered GREEN")
elif color == "BLACK":
    print("You entered BLACK")
else:
    print("Unknown color")
    
    
name = input("Enter any name:")
if name.isupper():
    print("String is upper")
elif name.islower():
    print("String is lowed")
else:
    print("Its mixed case")