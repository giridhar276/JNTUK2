# default arguments


def display(a=0,b=0,c=0):
    print(a,b,c)

display()        # 0 0 0
display(10)      # 10 0 0
display(10,20)   # 10 20 0
display(10,20,30)#10 20 30

print(10,20,sep="           ")