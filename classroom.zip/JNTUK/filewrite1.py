
# fobj = open("D:\\material\\npythoncode\\customers.txt","w")
# fobj = open("D:/material/npythoncode/customers.txt","w")
#fobj = open(r"D:\material\npythoncode\customers.txt","w") #raw string

fobj = open("customers.txt","w")

fobj.write("python programming\n")
fobj.write("hadoop adminstration\n")

fobj.close()

# write a program to write all the numbers 1 to 100 to the file line by line