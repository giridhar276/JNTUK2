# -*- coding: utf-8 -*-
"""
Created on Mon Sep 14 19:35:34 2020

@author: gsripath
"""

val = 1

while val <=10 :
    print("running")