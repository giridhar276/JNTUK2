

## not generally suggested
## it is best way to read somall config files
# it is displaiying the complete file at a time
with open("realestate.csv","r") as fobj:
    print(fobj.read())