
## using readlines()

# it is displaiying the complete file at a time
## output will be in the list format
with open("realestate.csv","r") as fobj:
    print(fobj.readlines())
    
    
## display some particular line    
with open("realestate.csv","r") as fobj:
    print(fobj.readlines()[5])    