adict = {"chap1":10 ,"chap2":20}

## adding new key-value pair to the dictionary
adict["chap3"] = 30
adict["chap4"] = 40
print("Dictionary elements are :", adict)

print("ONLY keys :", adict.keys())
print("ONLY values:", adict.values())
print("key-value paairs :", adict.items())

print(adict["chap1"])
print(adict["chap100"])
print(adict.get("chap1000"))

adict.pop("chap1")   # key-value will be removed from dictionary
print("After pop :", adict)

print(adict.popitem())  # will remove RANDOM key-value pairs
print(adict)




book1 = {"chap1":10 ,"chap2":20}
book2 = {"chap3":30 ,"chap4":40}

#final = book1 + book2
#print(final)

# adding two dictionaries
final = {**book1, **book2}
print(final)


# 2nd method
book1.update(book2)  # The items of book2 are assigned to book1
## book1 will be updated
print(book1)















