

# set methods

aset = {10,10,20,30}
bset = {30,40,50}

aset.add(100)
print("after addition:", aset)

print(aset)
print(bset)

print(aset.union(bset))
print(aset.intersection(bset))
print(aset.issubset(bset))
print(aset.issuperset(bset))
print(aset.difference(bset))