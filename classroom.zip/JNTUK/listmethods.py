


alist = [10,20,30,40,50,10,10,10,10,10,3,2,445]
print("length of list :", len(alist))
# to add an object
alist.append(45)
print("After appending :", alist)
alist.append(423)
alist.append(56)
print("After appending :", alist)

alist.extend([67,54,34,65])
print("After extending :", alist)

getcount = alist.count(10)   # no. of occurences
print("count of 10 :", getcount)

# insert(where to insert , what to insert)
# insert(index no, element)
alist.insert(0,10000)
print("After inserting :", alist)

alist.pop()   ## we are supposed to pass index
              ## If nothing is passed.. it will take the last index
print("After pop operation :", alist)

element_removed = alist.pop(0)  # 0 is the index
print("removed element is :", element_removed)
print("After pop operation :", alist)
alist.pop(2)  # 0 is the index
print("After pop operation :", alist)

alist.remove(10)  # 10 will be removed directly ## INDEX is not required
print(alist)
#alist.remove(40000)
#alist.remove(40000)

alist.reverse()   # INPLACE   ## list will be modified
print(alist)

# by default : ascending order
alist.sort()
print(alist)

# descending order
alist.sort(reverse=True)
print(alist)


