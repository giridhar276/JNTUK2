aset = {10,10,10,20,20}

print(aset)