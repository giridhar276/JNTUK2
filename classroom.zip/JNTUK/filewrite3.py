
# pythonic way 
# context manager
#if any line is starting with the keyword 'with'..it is known as context manager
# Advantage :  file will  be closed automatically  when it comes out of indentation

# network programming and database programming

with open("numbers.txt","w") as fobj:

    for val in range(1,101):
        #print(val)
        fobj.write(str(val) + "\n")

