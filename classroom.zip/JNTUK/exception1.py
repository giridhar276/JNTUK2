# fobj is file pointer or navigator or file reference

try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            # remove white spaces if any
            line = line.strip()
            print(line)
            
            
except Exception as error:
    print("User defined:","File doesn't exist")
    print("System error :",error)