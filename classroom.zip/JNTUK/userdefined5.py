
## variable length arguments
## If any object is prefixed with * ... it is called as tuple
def display(*info):
    print(info)
    for item in info:
        print(item)
    
display(10,20,30,40,50,60,45,6,45,645,634,36,45,4,53,435,34,63434)




## **
##  If any object is prefixed with ** ... it is dictionary

def displayData(**studinfo):
    for key,value in studinfo.items():
        print(key,value)


displayData(name='Rita',age=20,location='Hyderabad')

