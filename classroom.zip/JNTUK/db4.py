
import pymysql
import csv
#import cx_Oracle  ----> Oracle
#import pymssql   -----> SQLserver
#import pymongo   -----> Mongodb
try:
    #connecting to the database
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='information')
    #db = pymysql.connect(host='dbx45.oracle.com',port=3306,user='user1',password='india@123',database='information')
    if db:
        cursor = db.cursor()
        # inserting all the records from the file
        # open the file
        with open("realestate.csv","r") as fobj:
            # converting file object to csv object
            reader = csv.reader(fobj)
            for record in reader:
                #print(record)
                street = record[0]
                city = record[1]
                query = "insert into realestate values('{}','{}')".format(street,city)
                cursor.execute(query)
        db.commit()
    db.close()

except pymysql.OperationalError as err:
    print(err)
except pymysql.DataError as err:
    print(err)
except (pymysql.IntegrityError, pymysql.DataError) as err:
    print(err)
except Exception as err:
    print(err)    