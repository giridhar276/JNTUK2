
aname = 'python programming'
bname = "scala programming"
cname = """hadoop administration"""

print(aname)
print(bname)
##################### string slice
print(aname,bname,cname)
### sting[start:stop:step]
print(aname[0])
print(aname[1])
print(aname[0:5])
print(aname[3:7])
print(aname[2:])
print(aname[6:9])
print(aname[:])  ## python programming
print(aname[::]) ## python programming
print(aname[0:])
print(aname[0:16:2])
print(aname[1:16:2])
print(aname[-1])
print(aname[-2])
print(aname[::-1])   #gnimmargorp nohtyp






print(aname)
print(bname)
# concatenation
final = aname + bname
print(final)

print(aname + " " + bname)













