


import csv
# Advantage : Each line will be converted to LISt automatically
## fobj is file object used for reading any kind of file
with open("realestate.csv","r") as fobj:
    # converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        
