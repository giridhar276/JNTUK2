import os

print("Current directory:",os.getcwd())

print("Current Username :",os.getlogin())

## ls in linux
## list all the files
for file in os.listdir():
    print(file)
    
## files from D:    
for file in os.listdir("D:\\"):
    print(file)
    
os.remove("realestate.csv")

## write a program to delete all .txt files in your current directory
for file in os.listdir():
    if file.endswith(".txt")  and os.path.isfile(file):
        os.remove(file)


os.mkdir("testdir")



# write a program to create 100 directoreis in the below format
## in the current directory
for val in range(1,101):
    os.mkdir("dir" + str(val))

for val in range(1,101):
    os.rmdir("dir" + str(val))


#### create directories in D:\
path = "D:\\"
os.chdir(path)
for val in range(1,101):
    os.rmdir("dir" + str(val))


## create empty file in python
## empty file can also be created using library pathlib
fobj = open("abcd.txt","w")
fobj.close()



os.rename("abcd.txt","afterrenaming.txt")





### display ONLY directories
for file in os.listdir():
    if os.path.isdir(file):
        print(file)


### display ONLY directories
for file in os.listdir():
    if os.path.isfile(file):
        print(file)








    