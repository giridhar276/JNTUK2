

def increment(x):
    return x + 5

total = increment(10)
print(total)

# inline function  # lambda function
#syntax:
# function= lambda variables: expression
#lambda is the replacement of single liner function ONLY
#execution i faster using lambda
increment = lambda x : x + 5
total = increment(10)
print(total)


## example3
add = lambda x,y : x + y
total = add(10,20)


## function= lambda variables: expression
checkValue = lambda x: True if x == 100 else False

print(checkValue(1000))










