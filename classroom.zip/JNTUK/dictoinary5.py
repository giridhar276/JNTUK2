
# list of dictionaries
colors = [
   {
     "colors": "red",
     "values": "#f00"
   },
   {
     "colors": "green",
     "values": "#0f0"
   },
   {
     "colors": "blue",
     "values": "#00f"
   },
   {
     "colors": "black",
     "values": "#000"
   }
]

for item in colors:
    print(item['colors'], item['values'])