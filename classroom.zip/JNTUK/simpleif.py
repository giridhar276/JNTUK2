

## simple if
name  = input("Enter any language :")

if name == "python" :
    print("You are learning python programming")
    
    
    
## if-else
name  = input("Enter any language :")
if name == "python" :
    print("You are learning python programming")
    print("Inside if condition")
else:
    print("You are learning someother language")    