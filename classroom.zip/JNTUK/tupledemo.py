

atup = (35,45,43,4355,56)
btup = ("unix","java","ruby","perl")
ctup = (35,"python",56.54)


print(atup)
print(btup)
print(ctup)

atup[0] = 1000
print("updated tuple :", atup)