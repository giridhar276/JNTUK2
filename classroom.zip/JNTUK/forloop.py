############  for loop with range
## range(start,stop,step)
for val in range(1,11):
    print(val)
# even numbers    
for val in range(2,10,2):
    print(val)
## odd numbers
for val in range(1,10,2):
    print(val)
    
    
#  for loop with string
name = "python programming"
for char in name :
    print(char)
    
# for loop with list
alist =[10,20,430,403,4]
for value in alist:
    print(value)    
    
# dictionary
adict= {"chap1":10 ,"chap2":20,"chap3":30}    
for key in adict.keys():
    print(key)

for value in adict.values():
    print(value)
    
for key,value in adict.items():
    print(key,value)
    
    
    
    
    
    
    
    
    
    
    
    
    
    