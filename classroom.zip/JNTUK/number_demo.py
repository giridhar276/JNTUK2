# this is single line comment



aval = 10
bval = 45.4

print(aval)
print(bval)

print("Value is :", aval)

print("Values are :", aval,bval)
