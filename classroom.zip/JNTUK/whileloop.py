

flag = 1

while flag <= 100:
    print(flag)
    flag = flag + 1  #flag+=1`
    