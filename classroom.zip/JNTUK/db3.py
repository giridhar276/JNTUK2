
import pymysql
#import cx_Oracle  ----> Oracle
#import pymssql   -----> SQLserver
#import pymongo   -----> Mongodb
try:
    #connecting to the database
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='information')
    #db = pymysql.connect(host='dbx45.oracle.com',port=3306,user='user1',password='india@123',database='information')
    if db:
        cursor = db.cursor()
        query = "insert into realestate values('{}','{}')".format("GT Road","Chennai")
        cursor.execute(query)
        print(cursor.rowcount,"record inserted")
        db.commit()
    db.close()

except pymysql.OperationalError as err:
    print(err)
except pymysql.DataError as err:
    print(err)
except (pymysql.IntegrityError, pymysql.DataError) as err:
    print(err)
except Exception as err:
    print(err)    