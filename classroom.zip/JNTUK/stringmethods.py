

name = "apython programming"

print(name.capitalize())

print(name.upper())
print(name.lower())
print(name.isupper())
print(name.title())
print(name.center(70))
print(name.center(70,"*"))
print(name.replace("python","ruby"))
print(name.endswith("z"))
print(name.endswith("g"))
print(name.startswith("s"))  # False
print(name.startswith("p"))

if name.startswith("p"):
    print("yes... string is starting with upper case")
else:
    print("String is starting with someother character")
    
    
if name.isupper():
    print("String is defined in uppercase")
else:
    print("String is defined in lowercase")
    
# converting string to the list
name = "python:perl:oracle:hadoop"
print(name.split(":"))

# list to the string
alist = [ "unix","oracle","java"]

print(":".join(alist))

aname = "python"
print(len(aname))

aname = "   python "
print(len(aname))
aname = aname.strip()  # remove whitespace at both the ends
print("Length after removing white spaces :", len(aname))














