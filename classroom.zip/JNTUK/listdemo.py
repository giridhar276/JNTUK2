alist = [10,45,56,4,46,5,7645,4364]
blist = ["unix","linux","hadoop"]
clist = [45,6,56.5,"unix","oracle"]

print(alist)

print("List elements are :", alist)

# concatenation
output = alist + blist + clist
print(output)

print(alist[0])
print(alist[1])
print(alist[0:5])
print(alist[::2])
print(alist[::-1])

alist[0] = 1000
print("updated list :", alist)
