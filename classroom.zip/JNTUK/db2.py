

import pymysql
#import cx_Oracle  ----> Oracle
#import pymssql   -----> SQLserver
#import pymongo   -----> Mongodb
try:
    #connecting to the database
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='information')
    
    if db:
        cursor = db.cursor()
        query = "select * from realestate"
        cursor.execute(query)
        for record in cursor.fetchall():
            print(record)
    
    db.close()

except Exception as err:
    print(err)    