

# fobj is file pointer or navigator or file reference
with open("numbers.txt","r") as fobj:
    for line in fobj:
        # remove white spaces if any
        line = line.strip()
        print(line)