


print("Python programming")

print("unix","java")

print(1,2,3,4,5)

print("values are :", 1,2,3,4)