
# fixed arguments
def display(a,b):
    c = a + b
    return c

total = display(10,20)
print(total)